package store;
/**
 * Matthew Foley
 * @author 
 * June/July 2025
 */
public class setitems extends Product{
/**
 * sets the class's
 * @param quantity
 * using int
 * @param price
 * using int
 * @param name
 * using string
 */
	public setitems(int tempquant ,int quantity, int price, String name) {
		super(tempquant,quantity, price, name);
		// TODO Auto-generated constructor stub
	}
	 

}
